<?php

$method = $_SERVER['REQUEST_METHOD'];

//Script Foreach
$c = true;
if ( $method === 'POST' ) {

	$project_name = 'KimmberliBar (лендинг)';
	$admin_email  = 'kimberli.jewellery@gmail.com';
	$admin_email2  = 'marketing@kimberli.ua';
	$admin_email3  = 'Mdapple23@gmail.com';
	$admin_email4  = 'Kimberlibar@ukr.net';
	$admin_email5  = 'shpirniy06@gmail.com';
	$form_subject = 'Форма заявки';

	foreach ( $_POST as $key => $value ) {
		if ( $value != "" && $key != "project_name" && $key != "admin_email" && $key != "form_subject" ) {
			$message .= "
			" . ( ($c = !$c) ? '<tr>':'<tr style="background-color: #f8f8f8;">' ) . "
				<td style='padding: 10px; border: #e9e9e9 1px solid;'><b>$key</b></td>
				<td style='padding: 10px; border: #e9e9e9 1px solid;'>$value</td>
			</tr>
			";
		}
	}
} else if ( $method === 'GET' ) {

	$project_name = 'KimmberliBar (лендинг)';
	$admin_email  = 'kimberli.jewellery@gmail.com';
	$admin_email2  = 'marketing@kimberli.ua';
	$admin_email3  = 'Mdapple23@gmail.com';
	$admin_email4  = 'Kimberlibar@ukr.net';
	$admin_email5  = 'shpirniy06@gmail.com';
	$form_subject = 'Форма заявки';

	foreach ( $_GET as $key => $value ) {
		if ( $value != "" && $key != "project_name" && $key != "admin_email" && $key != "form_subject" ) {
			$message .= "
			" . ( ($c = !$c) ? '<tr>':'<tr style="background-color: #f8f8f8;">' ) . "
				<td style='padding: 10px; border: #e9e9e9 1px solid;'><b>$key</b></td>
				<td style='padding: 10px; border: #e9e9e9 1px solid;'>$value</td>
			</tr>
			";
		}
	}
}

$message = "<table style='width: 100%;'>$message</table>";

function adopt($text) {
	return '=?UTF-8?B?'.Base64_encode($text).'?=';
}

$headers = "MIME-Version: 1.0" . PHP_EOL .
"Content-Type: text/html; charset=utf-8" . PHP_EOL .
'From: '.adopt($project_name).' <'.$admin_email.'>' . PHP_EOL .
'Reply-To: '.$admin_email.'' . PHP_EOL;

/*$fd = fopen("numbers.txt", 'a');    
fwrite($fd, $value."\r\n");   
fclose($fd);*/

mail($admin_email, adopt($form_subject), $message, $headers );
mail($admin_email2, adopt($form_subject), $message, $headers );
mail($admin_email3, adopt($form_subject), $message, $headers );
mail($admin_email4, adopt($form_subject), $message, $headers );
mail($admin_email5, adopt($form_subject), $message, $headers );